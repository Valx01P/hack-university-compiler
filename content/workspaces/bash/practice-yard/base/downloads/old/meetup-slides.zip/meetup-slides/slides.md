# Shell tricks for web people

1. find
2. xargs
3. rsync
