# node-hello

Run it with `node index.js`.
